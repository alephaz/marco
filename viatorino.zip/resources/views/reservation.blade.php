<!DOCTYPE html>
<html lang="en-US" class="no-js no-svg">

<!-- Mirrored from marco.puruno.com/11/reservation/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 22 Mar 2021 07:15:20 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
@include('common/header')

<body data-rsssl=1 class="page-template-default page page-id-8 nav-classes nav-left nav-top nav-transparent nav-dark-text wpb-js-composer js-comp-ver-5.6 vc_responsive"  data-height-fixed-nav="80" >
	<div class="navigation-top">
		<div class="wrap">

<div class="main-navigation nav-standard" id="nav-helper">
	<div class="row">
		<div class="col-sm-12 columns">
			<div class="nav-wrapper">
				@include('common/navbar')						</div>
		</div>
	</div>
</div>

		</div>
	</div>
	@include('common/stickynb')
	<div class="page-wrapper">

	<div class="classic">
	<div class="row">
		<div class="small-12 columns small-centered blog-content">
									<div data-vc-full-width="true" data-vc-full-width-init="false" class="row-wrapper full-row "><div data-marco-parallax="0.5" style="background-image: url(../assets/img/gallery-1920x1080.jpg)" class="marco-parallax"><div class="row-image-overlay" style="background-color: rgba(0,0,0,0.68)"></div></div><div class=""><div class="large-12 columns"><div class="vc_column-inner "><div class="wpb_wrapper">	<div class="vc_empty_space" >
		<span class="vc_empty_space_inner"></span>
		<div class=""  style="height: 250px"></div>
			</div>

<div class="text-center page-header id_1605842a6014721320944687 animate-text alt-h"><div style="color: #ffffff"></p>
<h2>Booking your table</h2>
<p></div><div class="post-meta">
					<ul>
						<li>Share on:</li>
						<li><a href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fmarco.puruno.com%2F11%2Freservation%2F" class="no-rd social-share link-hover" data-djax-exclude="true">Facebook</a></li>
		<li><a href="https://www.twitter.com/share?text=Reservation" class="no-rd social-share link-hover" data-djax-exclude="true">Twitter</a></li>


		<li><a href="https://pinterest.com/pin/create/bookmarklet/?media=&amp;url=https%3A%2F%2Fmarco.puruno.com%2F11%2Freservation%2F&amp;is_video=0&amp;description=" class="no-rd social-share link-hover" data-djax-exclude="true">Pinterest</a></li>
					</ul>
				</div></div><div class="custom-styles" data-styles=".id_1605842a6014721320944687 .post-meta li a, .id_1605842a6014721320944687 .post-meta { color: #ffffff } .id_1605842a6014721320944687 .link-hover:after {background:#ffffff}"></div>	<div class="vc_empty_space" >
		<span class="vc_empty_space_inner"></span>
		<div class=""  style="height: 200px"></div>
			</div>

</div></div></div></div><div class="vc_row-full-width vc_clearfix"></div> </div><div class="vc_row-full-width vc_clearfix"></div><div  class="row-wrapper  "><div class=""><div class="large-12 columns"><div class="vc_column-inner "><div class="wpb_wrapper">	<div class="vc_empty_space" >
		<span class="vc_empty_space_inner"></span>
		<div class=""  style="height: 100px"></div>
			</div>

</div></div></div></div><div class="vc_row-full-width vc_clearfix"></div> </div><div  class="row-wrapper  "><div class=""><div class="large-12 columns"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="form-container reservation-container id_1605842a601d3e636623270 form-with-image img_right"><div class="forms-style reservation-form marco-form animate-text">
					<div class="form-wrapper">
						<form name="bf-form" id="bf-form" class="bf-form" action="https://marco.puruno.com/11/reservation/reservation_send_message" method="POST">
							<input type="hidden" name="action" value="reservation_send_message">
							<input type="hidden" name="bf[subtitle]" id="bf_subtitle" value="Booking form">
							<input type="hidden" name="bf[response_message]" id="bf_response_message" value="Your message was sent successfully">
							<input type="hidden" name="bf[your_email]" id="bf_your_email" value="1">
							<fieldset class="reservation-details">
								<div class="bf-text date bf-input mf-input">
									<label for="bf_date" style="color: #111111">Date</label>
									<input class="input-required" type="text" name="bf[date]" id="bf_date" style="color: #111111">
								</div>
								<div class="bf-text time bf-input mf-input">
									<label for="bf_time" style="color: #111111">Time</label>
									<input class="input-required" type="text" name="bf[time]" id="bf_time" style="color: #111111">
								</div>
								<div class="bf-text people bf-input mf-input">
									<label for="bf_people" style="color: #111111">Party size</label>
									<input class="input-required" type="text" name="bf[people]" id="bf_people" style="color: #111111">
								</div>
							</fieldset>
							<fieldset class="contact">
								<div class="bf-text name bf-input mf-input">
									<label for="bf_name" style="color: #111111">Name</label>
									<input class="input-required" type="text" name="bf[name]" id="bf_name" value="" style="color: #111111">
								</div>
								<div class="bf-text email bf-input mf-input">
									<label for="bf_email" style="color: #111111">Email</label>
									<input class="input-required" type="text" name="bf[email]" id="bf_email" value="" style="color: #111111">
								</div>

								<div class="bf-text phone bf-input mf-input">
									<label for="bf_phone" style="color: #111111">Phone</label>
									<input type="tel" name="bf[phone]" id="bf_phone" value="" style="color: #111111">
								</div>
							</fieldset>
							<fieldset class="message">
								<div class="bf-textarea message bf-input mf-input">
									<label for="bf_message" style="color: #111111">Message</label>
									<textarea rows="1" name="bf[message]" id="bf_message" style="color: #111111"></textarea>
									<div class="border-label"></div>
								</div>
							</fieldset>

							<div class="text-center"><button type="submit" class="btn btn-lg btn-border-animate btn-dark   btn-reservation">
				<span class="btn-text ">Booking now<span class="top button-border"></span>
				<span class="left left-bottom button-border"></span>
				<span class="left left-top button-border"></span>
				<span class="bottom bottom-right button-border"></span>
				<span class="bottom bottom-left button-border"></span>
				<span class="right button-border"></span></span>
			</button></div>
						</form>
					</div>
				</div><div class="form-image">
					<div class="form-image-wrapper show-for-large">
						<span class="img-wrapper">
							<img width="683" height="1024" src="../wp-content/uploads/sites/40/2017/01/reservation1-683x1024.jpg" class="attachment-large size-large" alt="" srcset="https://marco.puruno.com/11/wp-content/uploads/sites/40/2017/01/reservation1.jpg 683w, https://marco.puruno.com/11/wp-content/uploads/sites/40/2017/01/reservation1-200x300.jpg 200w" sizes="(max-width: 683px) 100vw, 683px" />
						</span>
					</div>
				</div></div><div class="custom-styles" data-styles=".id_1605842a601d3e636623270 .reservation-form fieldset:after { background-color: #dddddd; } .id_1605842a601d3e636623270 .forms-style .bf-input:not(.message):after,.id_1605842a601d3e636623270 .forms-style .bf-input .border-label:after { background-color: #111111; }"></div></div></div></div></div><div class="vc_row-full-width vc_clearfix"></div> </div><div data-vc-full-width="true" data-vc-full-width-init="false" class="row-wrapper full-row vc_custom_1484923752149"><div class=""><div class="large-6 columns"><div class="vc_column-inner vc_custom_1484918366919"><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<p><strong>Booking a table</strong></p>
<p>Booking is easy. To make reservation, please call us at +1 555 890 901 between 9am-8pm, Monday to Friday or use the form above.</p>
<p>There are <em>always</em> 10% of walk-ins ready places. We do not book sofa &amp; bar area.</p>

		</div>
	</div>
</div></div></div><div class="large-6 columns"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<p><strong>Private dining &amp; events</strong></p>
<p>There are four private spaces available for lunch, dinner or indeed at any other time like <a href="../../11a/index.html#">receptions</a>, <a href="../../11a/index.html#">presentations</a> or <a href="../../11a/index.html#">brainstorms</a>. In addition the restaurant is available for breakfast &amp; private hire as are all the other spaces.</p>
<p><a href="../../11a/index.html#"><em>Learn more</em></a></p>

		</div>
	</div>
</div></div></div></div><div class="vc_row-full-width vc_clearfix"></div> </div><div class="vc_row-full-width vc_clearfix"></div><div data-vc-full-width="true" data-vc-full-width-init="false" class="row-wrapper full-row "><div data-marco-parallax="0.5" style="background-image: url(../assets/img/2-6-1920x1080.jpg)" class="marco-parallax"><div class="row-image-overlay" style="background-color: rgba(0,0,0,0.68)"></div></div><div class=""><div class="large-12 columns"><div class="vc_column-inner "><div class="wpb_wrapper">	<div class="vc_empty_space" >
		<span class="vc_empty_space_inner"></span>
		<div class=""  style="height: 150px"></div>
			</div>

<div class="text-center page-header id_1605842a60298e34722577 animate-text alt-h"><div style="color: #ffffff"></p>
<h2>Private dining &amp; events</h2>
<p></div><div class="post-meta">
					<ul>
						<li>Share on:</li>
						<li><a href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fmarco.puruno.com%2F11%2Freservation%2F" class="no-rd social-share link-hover" data-djax-exclude="true">Facebook</a></li>
		<li><a href="https://www.twitter.com/share?text=Reservation" class="no-rd social-share link-hover" data-djax-exclude="true">Twitter</a></li>


		<li><a href="https://pinterest.com/pin/create/bookmarklet/?media=&amp;url=https%3A%2F%2Fmarco.puruno.com%2F11%2Freservation%2F&amp;is_video=0&amp;description=" class="no-rd social-share link-hover" data-djax-exclude="true">Pinterest</a></li>
					</ul>
				</div></div><div class="custom-styles" data-styles=".id_1605842a60298e34722577 .post-meta li a, .id_1605842a60298e34722577 .post-meta { color: #ffffff } .id_1605842a60298e34722577 .link-hover:after {background:#ffffff}"></div>	<div class="vc_empty_space" >
		<span class="vc_empty_space_inner"></span>
		<div class=""  style="height: 32px"></div>
			</div>

<div class="text-center animate-text"><a href="../../1/private-dining/index.html"  class="btn btn-md btn-border-animate btn-light   ">
				<span class="btn-text ">Learn more<span class="top button-border"></span>
				<span class="left left-bottom button-border"></span>
				<span class="left left-top button-border"></span>
				<span class="bottom bottom-right button-border"></span>
				<span class="bottom bottom-left button-border"></span>
				<span class="right button-border"></span></span>
			</a></div>	<div class="vc_empty_space" >
		<span class="vc_empty_space_inner"></span>
		<div class=""  style="height: 150px"></div>
			</div>

</div></div></div></div><div class="vc_row-full-width vc_clearfix"></div> </div><div class="vc_row-full-width vc_clearfix"></div>
		</div>
			</div>
</div>

</div>
@include('common/footer')
@include('common/script')
</body>

<!-- Mirrored from marco.puruno.com/11/reservation/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 22 Mar 2021 07:15:21 GMT -->
</html>
<!--
Performance optimized by W3 Total Cache. Learn more: https://www.w3-edge.com/products/

Page Caching using disk: enhanced (SSL caching disabled)
Database Caching 106/115 queries in 0.012 seconds using disk

Served from: marco.puruno.com @ 2021-03-22 07:09:26 by W3 Total Cache
-->
