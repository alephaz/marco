<script type='text/javascript'>
    var ajaxurl = 'wp-admin/admin-ajax.html';
            var pageId = '666';
    </script>
    <script type='text/javascript' src="{{ asset('assets/js/libs.js')}}"></script>
    <script type='text/javascript' src="{{ asset('assets/js/smooth-scroll.js')}}"></script>
    <script type='text/javascript' src="{{ asset('assets/js/app.js')}}"></script>
    <script type='text/javascript' src="{{ asset('assets/js/scripts.min.js')}}"></script>
    <script type='text/javascript' src="{{ asset('assets/js/jquery.cycle2.min.js')}}"></script>
    <script type='text/javascript' src="{{ asset('assets/js/embed.min.js')}}"></script>
    <script type='text/javascript' src="{{ asset('assets/js/js_composer_front.min.js')}}"></script>
    <script type='text/javascript' src="{{ asset('assets/js/jquery.zoom.min.js')}}"></script>
    <script type='text/javascript' src="{{ asset('assets/js/vc_image_zoom.min.js')}}"></script>
    <script type='text/javascript' src="{{ asset('assets/js/booking-form.js')}}"></script>
