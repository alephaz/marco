<div class="footer">
	<aside class="row footer-grid animate-text">
		<div class="small-12 large-3 columns">
					<div class="footer-content footer-widget-1">
				<section id="text-2" class="widget widget_text"><h6 class="widget-title"><span>Marco Restaurant</span></h6>			<div class="textwidget"><p>The Hoe, PL48RT<br />
Plymouth, UK</p>
<p><a href="#" class="link-hover link-hover-text">Get directions</a></p>
<p><a href="#" class="link-hover">Facebook</a><br />
<a href="#" class="link-hover">Snapchat</a><br />
<a href="#" class="link-hover">Instagram</a></p>
</div>
		</section>			</div>
				</div>
		<div class="small-12 large-3 columns">
					<div class="footer-content footer-widget-2">
				<section id="text-5" class="widget widget_text"><h6 class="widget-title"><span>Reservation</span></h6>			<div class="textwidget"><p><a href="mailto:hello@marco.com" class="link-hover link-hover-text">book@marco.com</a><br />
+ 166 900 891</p>
</div>
		</section><section id="text-6" class="widget widget_text"><h6 class="widget-title"><span>Private dining</span></h6>			<div class="textwidget"><p><a href="mailto:hello@marco.com" class="link-hover link-hover-text">private@marco.com</a><br />
+ 166 900 891</p>
</div>
		</section>			</div>
				</div>
		<div class="small-12 large-3 columns">
					<div class="footer-content footer-widget-3">
				<section id="newsletter_widget-2" class="widget widget widget-wrapper widget-newsletter"><h6 class="widget-title"><span>Newsletter</span></h6><p>Spam free, tasty news in your inbox. Once a week.</p><div class="forms-style newsletter-form">
				<div class="newsletter-form-wrapper">
					<form name="n-form" class="n-form" id="n-form" action="https://marco.puruno.com/11/newsletter_request" method="POST" ><input type="hidden" name="action" value="newsletter_request">
						<fieldset class="newsletter-details">
							<div class="n-text email n-input mf-input">
								<label for="n_email">E-mail</label>
								<input class="input-required" type="text" name="n[email]" id="n_email" value="">
							</div>
						</fieldset>
						<div class="text-right"><button type="submit" class="btn btn-xs btn-border-animate btn-dark   btn-newsletter">
					<span class="btn-text ">Submit<span class="top button-border"></span>
					<span class="left left-bottom button-border"></span>
					<span class="left left-top button-border"></span>
					<span class="bottom bottom-right button-border"></span>
					<span class="bottom bottom-left button-border"></span>
					<span class="right button-border"></span></span>
				</button></div>
						<input type="hidden" name="newsletter_list" class="newsletter_list" value="b59b3851bc" />
						<input type="hidden" name="newsletter_nonce" class="newsletter_nonce" value="b908af0493" />
					</form>
				</div>
			</div>
			</section>			</div>
				</div>
		<div class="small-12 large-3 columns">
			<div class="footer-content footer-widget-4">
								<div class="btn btn-border-animate" id="scroll-up">
					<svg xmlns="http://www.w3.org/2000/svg" class="arrow-svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="20px" height="40px" viewBox="0 0 50 100" preserveAspectRatio="xMidYMid meet" zoomAndPan="disable"><line class="arrow-svg-top" stroke="#171717" x1="15" y1="25" x2="25" y2="15" style="stroke-width: 1px; vector-effect: non-scaling-stroke; fill: none;"/><line class="arrow-svg-top" stroke="#171717" x1="25" y1="15" x2="35" y2="25" style="stroke-width: 1px; vector-effect: non-scaling-stroke; fill: none;"/><line class="arrow-svg-ver" stroke="#171717" style="stroke-width: 1px; vector-effect: non-scaling-stroke; fill: none;" shape-rendering="crispEdges" x1="25" y1="15" x2="25" y2="85"/></svg>					<span class="top button-border"></span>
					<span class="left left-bottom button-border"></span>
					<span class="left left-top button-border"></span>
					<span class="bottom bottom-right button-border"></span>
					<span class="bottom bottom-left button-border"></span>
					<span class="right button-border"></span>
				</div>
			</div>
		</div>
	</aside>
</div>
