<!DOCTYPE html>
<html lang="en-US" class="no-js no-svg">

<!-- Mirrored from marco.puruno.com/11/contact/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 22 Mar 2021 07:15:24 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
@include('common/header')

<body data-rsssl=1 class="page-template-default page page-id-12 nav-classes nav-left nav-top nav-transparent nav-dark-text wpb-js-composer js-comp-ver-5.6 vc_responsive"  data-height-fixed-nav="80" >
	<div class="navigation-top">
		<div class="wrap">

<div class="main-navigation nav-standard" id="nav-helper">
	<div class="row">
		<div class="col-sm-12 columns">
			<div class="nav-wrapper">
				@include('common/navbar')
            </div>
		</div>
	</div>
</div>

		</div>
	</div>
    @include('common/stickynb')
	<div class="page-wrapper">

	<div class="classic">
	<div class="row">
		<div class="small-12 columns small-centered blog-content">
									<div data-vc-full-width="true" data-vc-full-width-init="false" class="row-wrapper full-row "><div data-marco-parallax="1" style="background-image: url(../assets/img/s44.jpg)" class="marco-parallax"><div class="row-image-overlay" style="background-color: rgba(0,0,0,0.68)"></div></div><div class="vc_row-o-content-middle vc_row-flex"><div class="large-12 columns"><div class="vc_column-inner "><div class="wpb_wrapper">	<div class="vc_empty_space" >
		<span class="vc_empty_space_inner"></span>
		<div class=""  style="height: 250px"></div>
			</div>

<div class="text-center page-header id_1605842a6bea501571300944 animate-text alt-h"><div style="color: #ffffff"></p>
<h2>Have a question?</h2>
<p></div><div class="post-meta">
					<ul>
						<li>Share on:</li>
						<li><a href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fmarco.puruno.com%2F11%2Fcontact%2F" class="no-rd social-share link-hover" data-djax-exclude="true">Facebook</a></li>
		<li><a href="https://www.twitter.com/share?text=Contact" class="no-rd social-share link-hover" data-djax-exclude="true">Twitter</a></li>


		<li><a href="https://pinterest.com/pin/create/bookmarklet/?media=&amp;url=https%3A%2F%2Fmarco.puruno.com%2F11%2Fcontact%2F&amp;is_video=0&amp;description=" class="no-rd social-share link-hover" data-djax-exclude="true">Pinterest</a></li>
					</ul>
				</div></div><div class="custom-styles" data-styles=".id_1605842a6bea501571300944 .post-meta li a, .id_1605842a6bea501571300944 .post-meta { color: #ffffff } .id_1605842a6bea501571300944 .link-hover:after {background:#ffffff}"></div>	<div class="vc_empty_space" >
		<span class="vc_empty_space_inner"></span>
		<div class=""  style="height: 200px"></div>
			</div>

</div></div></div></div><div class="vc_row-full-width vc_clearfix"></div> </div><div class="vc_row-full-width vc_clearfix"></div><div  class="row-wrapper  vc_custom_1485176287309"><div class=""><div class="large-6 columns"><div class="vc_column-inner vc_custom_1486374956222"><div class="wpb_wrapper"><div class="text-left page-header id_1605842a6bf210214511547 animate-text "><div style="color: #333333"></p>
<h4>We are open daily, we server seasonal food, fish and meat. All freshly cooked.</h4>
<p></div><div class="post-meta">
					<ul>
						<li>Share on:</li>
						<li><a href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fmarco.puruno.com%2F11%2Fcontact%2F" class="no-rd social-share link-hover" data-djax-exclude="true">Facebook</a></li>
		<li><a href="https://www.twitter.com/share?text=Contact" class="no-rd social-share link-hover" data-djax-exclude="true">Twitter</a></li>


		<li><a href="https://pinterest.com/pin/create/bookmarklet/?media=&amp;url=https%3A%2F%2Fmarco.puruno.com%2F11%2Fcontact%2F&amp;is_video=0&amp;description=" class="no-rd social-share link-hover" data-djax-exclude="true">Pinterest</a></li>
					</ul>
				</div></div><div class="custom-styles" data-styles=".id_1605842a6bf210214511547 .post-meta li a, .id_1605842a6bf210214511547 .post-meta { color: #333333 } .id_1605842a6bf210214511547 .link-hover:after {background:#333333}"></div></div></div></div><div class="large-6 columns"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<p>+12 665 666 667<br />
<a href="mailto:hello@marco.com">hello@marco.com</a></p>
<p>We are open daily to serve best food possible.</p>
<p>Monday &#8211;  Friday: 10am &#8211; 9pm<br />
Saturaday: 10am &#8211; 10pm<br />
Sunday: 12am &#8211; 5pm</p>

		</div>
	</div>
</div></div></div></div><div class="vc_row-full-width vc_clearfix"></div> </div><div  class="row-wrapper  "><div class=""><div class="large-12 columns"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="text-center page-header id_1605842a6bf9d71452049548 animate-text "><div style="color: #333333"></p>
<h4>For any enquiries please use the form below</h4>
<p></div></div><div class="custom-styles" data-styles=".id_1605842a6bf9d71452049548 .post-meta li a, .id_1605842a6bf9d71452049548 .post-meta { color: #333333 } .id_1605842a6bf9d71452049548 .link-hover:after {background:#333333}"></div>	<div class="vc_empty_space" >
		<span class="vc_empty_space_inner"></span>
		<div class=""  style="height: 50px"></div>
			</div>

<div class="form-container contact-container id_1605842a6bfb631345269560 form-with-image img_left"><div class="form-image">
					<div class="form-image-wrapper show-for-large">
						<span class="img-wrapper">
							<img width="683" height="1024" src="../wp-content/uploads/sites/40/2017/01/reservation-683x1024.jpg" class="attachment-large size-large" alt="" srcset="https://marco.puruno.com/11/wp-content/uploads/sites/40/2017/01/reservation.jpg 683w, https://marco.puruno.com/11/wp-content/uploads/sites/40/2017/01/reservation-200x300.jpg 200w" sizes="(max-width: 683px) 100vw, 683px" />
						</span>
					</div>
				</div><div class="forms-style contact-form marco-form animate-text">
					<div class="form-wrapper">
						<form name="c-form" id="c-form" class="c-form" action="https://marco.puruno.com/11/contact/send_message" method="POST">
							<input type="hidden" name="action" value="send_message">
							<input type="hidden" name="c[subtitle]" id="c_subtitle" value="">
							<input type="hidden" name="c[response_message]" id="c_response_message" value="Your message was sent successfully">
							<input type="hidden" name="c[your_email]" id="c_your_email" value="1">
							<fieldset class="contact-details">
								<div class="c-text name c-input mf-input">
									<label for="c_name" style="color: #111111">Name</label>
									<input class="input-required" type="text" name="c[name]" id="c_name" value="" style="color: #111111">
								</div>
								<div class="c-text email c-input mf-input">
									<label for="c_email" style="color: #111111">Email</label>
									<input class="input-required" type="text" name="c[email]" id="c_email" value="" style="color: #111111">
								</div>
								<div class="c-text phone c-input mf-input">
									<label for="c_phone" style="color: #111111">Phone</label>
									<input type="tel" name="c[phone]" id="c_phone" value="" style="color: #111111">
								</div>
							</fieldset>
							<fieldset class="message">
								<div class="c-textarea message c-input mf-input">
									<label for="c_message" style="color: #111111">Message</label>
									<textarea rows="1" name="c[message]" id="c_message" style="color: #111111"></textarea>
									<div class="border-label"></div>
								</div>
							</fieldset>

							<div class="text-center"><button type="submit" class="btn btn-lg btn-border-animate btn-dark   btn-contact">
				<span class="btn-text ">Send<span class="top button-border"></span>
				<span class="left left-bottom button-border"></span>
				<span class="left left-top button-border"></span>
				<span class="bottom bottom-right button-border"></span>
				<span class="bottom bottom-left button-border"></span>
				<span class="right button-border"></span></span>
			</button></div>
						</form>
					</div>
				</div></div><div class="custom-styles" data-styles="id_1605842a6bfb631345269560 .contact-form fieldset:after { background-color: #dddddd;  }
				.id_1605842a6bfb631345269560 .forms-style .c-input:not(.message):after,.id_1605842a6bfb631345269560 .forms-style .c-input .border-label:after { background-color: #111111;  }"></div></div></div></div></div><div class="vc_row-full-width vc_clearfix"></div> </div><div  class="row-wrapper  "><div class=""><div class="large-12 columns"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="text-center page-header id_1605842a6c02251616045408 animate-text "><div style="color: #333333"></p>
<div class="wpb_text_column wpb_content_element ">
<div class="wpb_wrapper">
<h4>We are here, come by.</h4>
</div>
</div>
<p></div></div><div class="custom-styles" data-styles=".id_1605842a6c02251616045408 .post-meta li a, .id_1605842a6c02251616045408 .post-meta { color: #333333 } .id_1605842a6c02251616045408 .link-hover:after {background:#333333}"></div>	<div class="vc_empty_space" >
		<span class="vc_empty_space_inner"></span>
		<div class=""  style="height: 50px"></div>
			</div>

<div class="wpb_gmaps_widget wpb_content_element" >
		<div class="wpb_wrapper">
		<div class="wpb_map_wraper">
			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d5089.960987415465!2d-4.1609470546245255!3d50.366918199918146!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x57024ac8819699c7!2sThe+Dock!5e0!3m2!1sen!2spl!4v1484918597006" width="600" height="500" frameborder="0" style="border:0" allowfullscreen></iframe>		</div>
	</div>
</div>
</div></div></div></div><div class="vc_row-full-width vc_clearfix"></div> </div><div  class="row-wrapper  "><div class=""><div class="large-12 columns"><div class="vc_column-inner "><div class="wpb_wrapper">	<div class="vc_empty_space" >
		<span class="vc_empty_space_inner"></span>
		<div class=""  style="height: 100px"></div>
			</div>

</div></div></div></div><div class="vc_row-full-width vc_clearfix"></div> </div>
		</div>
			</div>
</div>

</div>
@include('common/footer')
@include('common/script')
</body>

<!-- Mirrored from marco.puruno.com/11/contact/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 22 Mar 2021 07:15:25 GMT -->
</html>
<!--
Performance optimized by W3 Total Cache. Learn more: https://www.w3-edge.com/products/

Page Caching using disk: enhanced (SSL caching disabled)
Database Caching 104/113 queries in 0.015 seconds using disk

Served from: marco.puruno.com @ 2021-03-22 07:09:26 by W3 Total Cache
-->
