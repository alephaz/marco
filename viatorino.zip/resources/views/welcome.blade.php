<!DOCTYPE html>
<html lang="en-US" class="no-js no-svg">

<!-- Mirrored from marco.puruno.com/11/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 22 Mar 2021 07:09:20 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->

@include('common/header')
<body data-rsssl=1 class="home page-template page-template-page-templates page-template-home page-template-page-templateshome-php page page-id-666 nav-classes nav-left nav-bottom nav-home nav-solid nav-dark-text wpb-js-composer js-comp-ver-5.6 vc_responsive"  data-height-fixed-nav="80" >
	<div class="navigation-top">
		<div class="wrap">

@include('common/navbar')

		</div>
	</div>
	@include('common/stickynb')
	<div class="page-wrapper">



<div class="homepage homepage-slider1" data-auto="true" data-transition="" data-duration="8000">
<div class="home-bg-slider autoplay">
	<div class="home-overlay active-overlay"></div>
	<div class="home-slider-container">


									<span class="single-slide" data-slide="{{ asset('assets/img/bg-marco11a.jpg') }}"></span>
														<span class="single-slide" data-slide="{{ asset('assets/img/bg-marco11b-1920x1080.jpg') }}"></span>
														<span class="single-slide" data-slide="{{ asset('assets/img/bg-marco11c-1920x1080.jpg') }}"></span>
															</div>
			<div class="home-slider-arrows show-for-large">
			<div class="arrow-prev">
				<svg id="icon-big-arrow-prev" xmlns="http://www.w3.org/2000/svg" class="arrow-svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="90px" height="50px" viewBox="0 0 100 50" preserveAspectRatio="xMidYMid meet" zoomAndPan="disable"><line class="arrow-svg-hor" shape-rendering="crispEdges" x1="0" y1="25" x2="100" y2="25"/><line class="arrow-svg-ver" x1="0" y1="25" x2="10" y2="15"/><line class="arrow-svg-ver" x1="0" y1="25" x2="10" y2="35"/></svg>			</div>
			<div class="arrow-next">
				<svg id="icon-big-arrow-next" xmlns="http://www.w3.org/2000/svg" class="arrow-svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="90px" height="50px" viewBox="0 0 100 50" preserveAspectRatio="xMidYMid meet" zoomAndPan="disable"><line class="arrow-svg-hor" shape-rendering="crispEdges" x1="0" y1="25" x2="100" y2="25"/><line class="arrow-svg-ver" x1="90" y1="15" x2="100" y2="25"/><line class="arrow-svg-ver" x1="90" y1="35" x2="100" y2="25"/></svg>			</div>
		</div>
		<div class="row home-content">
		<div class="small-12 columns">
			<div class="content show-content">
								<div class="home-slider-text">
										<div class="slider-text">
												<h2>
														<span class="slider-text-first">Welcome</span>
																					<span class="slider-text-second">exclusive drinking &amp; dining</span>
													</h2>
																								<a href="../wp/11/reservation/index.html" class="btn btn-md btn-border-animate btn-light  slider-text-third">
							<span class="btn-text ">Reservation</span>
							<span class="top button-border"></span><span class="left left-bottom button-border"></span><span class="left left-top button-border"></span><span class="bottom bottom-right button-border"></span><span class="bottom bottom-left button-border"></span><span class="right button-border"></span>						</a>
											</div>
									</div>
							<div class="home-slider-pagination show-for-large home-top home-left"><div class="progress-slide"></div></div>						<div class="home-contact-info show-for-large home-top home-right"><p style="text-align: right;"><a href="mailto:hello@macro.com">hello@macro.com</a><br />
+44 12 333 890 980</p>
</div>
											<div class="btn-show-picture btn-slider-1 btn-slider-active show-for-large home-bottom home-right">
							<a class="show-img" href="#">Show picture</a>
						</div>
						<div class="btn-show-content btn-slider-1 home-bottom home-right">
							<a class="show-content" href="#">Show content</a>
						</div>
											<ul class="home-social-media show-for-large home-bottom home-left">
							<li><a class="link-hover" target="_blank" href="#">Facebook</a></li><li><a class="link-hover" target="_blank" href="#">TripAdvisor</a></li><li><a class="link-hover" target="_blank" href="#">Yelp</a></li>						</ul>
											</div>
		</div>

	</div>
</div>
</div>
<div class="home-mobile-icon hide-for-large">
		<div class="icon-contact-mobile homepage-icon">
		<a class="phone-icon" href="tel:48700800900">
			<svg version="1.1" id="icon-phone-contact" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 578.106 578.106" xml:space="preserve"><path d="M577.83,456.128c1.225,9.385-1.635,17.545-8.568,24.48l-81.396,80.781 c-3.672,4.08-8.465,7.551-14.381,10.404c-5.916,2.857-11.729,4.693-17.439,5.508c-0.408,0-1.635,0.105-3.676,0.309 c-2.037,0.203-4.689,0.307-7.953,0.307c-7.754,0-20.301-1.326-37.641-3.979s-38.555-9.182-63.645-19.584 c-25.096-10.404-53.553-26.012-85.376-46.818c-31.823-20.805-65.688-49.367-101.592-85.68 c-28.56-28.152-52.224-55.08-70.992-80.783c-18.768-25.705-33.864-49.471-45.288-71.299 c-11.425-21.828-19.993-41.616-25.705-59.364S4.59,177.362,2.55,164.51s-2.856-22.95-2.448-30.294 c0.408-7.344,0.612-11.424,0.612-12.24c0.816-5.712,2.652-11.526,5.508-17.442s6.324-10.71,10.404-14.382L98.022,8.756 c5.712-5.712,12.24-8.568,19.584-8.568c5.304,0,9.996,1.53,14.076,4.59s7.548,6.834,10.404,11.322l65.484,124.236 c3.672,6.528,4.692,13.668,3.06,21.42c-1.632,7.752-5.1,14.28-10.404,19.584l-29.988,29.988c-0.816,0.816-1.53,2.142-2.142,3.978 s-0.918,3.366-0.918,4.59c1.632,8.568,5.304,18.36,11.016,29.376c4.896,9.792,12.444,21.726,22.644,35.802 s24.684,30.293,43.452,48.653c18.36,18.77,34.68,33.354,48.96,43.76c14.277,10.4,26.215,18.053,35.803,22.949 c9.588,4.896,16.932,7.854,22.031,8.871l7.648,1.531c0.816,0,2.145-0.307,3.979-0.918c1.836-0.613,3.162-1.326,3.979-2.143 l34.883-35.496c7.348-6.527,15.912-9.791,25.705-9.791c6.938,0,12.443,1.223,16.523,3.672h0.611l118.115,69.768 C571.098,441.238,576.197,447.968,577.83,456.128z"/></svg>		</a>
	</div>
		</div>
<div class="page-wrapper" style="width: 100%; position: relative;">
	<div class="classic">
		<div class="row">
				<div  class="row-wrapper  vc_custom_1485243761347"><div id="taste" class="vc_row-o-equal-height vc_row-o-content-middle vc_row-flex"><div class="large-6 columns"><div class="vc_column-inner vc_custom_1485165641158"><div class="wpb_wrapper"><div class="text-center page-header id_160584271c58a1499887302 animate-text alt-h"><div style="color: #333333"></p>
<h3>Our flavours</h3>
<p></div><div class="post-meta">
					<ul>
						<li>Share on:</li>
						<li><a href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fmarco.puruno.com%2F11%2F" class="no-rd social-share link-hover" data-djax-exclude="true">Facebook</a></li>
		<li><a href="https://www.twitter.com/share?text=home-alt" class="no-rd social-share link-hover" data-djax-exclude="true">Twitter</a></li>


		<li><a href="https://pinterest.com/pin/create/bookmarklet/?media=&amp;url=https%3A%2F%2Fmarco.puruno.com%2F11%2F&amp;is_video=0&amp;description=" class="no-rd social-share link-hover" data-djax-exclude="true">Pinterest</a></li>
					</ul>
				</div></div><div class="custom-styles" data-styles=".id_160584271c58a1499887302 .post-meta li a, .id_160584271c58a1499887302 .post-meta { color: #333333 } .id_160584271c58a1499887302 .link-hover:after {background:#333333}"></div>	<div class="vc_empty_space" >
		<span class="vc_empty_space_inner"></span>
		<div class=""  style="height: 32px"></div>
			</div>


	<div class="wpb_text_column wpb_content_element  vc_custom_1485163410392" >
		<div class="wpb_wrapper">
			<p style="text-align: center;">Marco is a restaurant, bar and coffee roastery located on a busy corner site in Plymouth Hoe. With glazed frontage on two sides of the building.</p>

		</div>
	</div>
<div class="text-center animate-text"><a href="#"  class="btn btn-sm btn-border-animate btn-dark   ">
				<span class="btn-text ">About us<span class="top button-border"></span>
				<span class="left left-bottom button-border"></span>
				<span class="left left-top button-border"></span>
				<span class="bottom bottom-right button-border"></span>
				<span class="bottom bottom-left button-border"></span>
				<span class="right button-border"></span></span>
			</a></div></div></div></div><div class="large-6 columns"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="row row_inner"><div class="large-6 small-6 columns"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_single_image wpb_content_element vc_align_left">

		<figure class="wpb_wrapper vc_figure">
			<div class="vc_single_image-wrapper img-wrapper   vc_box_border_grey"><img data-vc-zoom="https://marco.puruno.com/11/wp-content/uploads/sites/40/2017/01/menu2.jpg" width="380" height="600" src="wp-content/uploads/sites/40/2017/01/menu2.jpg" class="vc_single_image-img attachment-full" alt="" srcset="https://marco.puruno.com/11/wp-content/uploads/sites/40/2017/01/menu2.jpg 380w, https://marco.puruno.com/11/wp-content/uploads/sites/40/2017/01/menu2-190x300.jpg 190w" sizes="(max-width: 380px) 100vw, 380px" /></div>
		</figure>
	</div>
</div></div></div><div class="large-6 small-6 columns"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_single_image wpb_content_element vc_align_left">

		<figure class="wpb_wrapper vc_figure">
			<div class="vc_single_image-wrapper img-wrapper   vc_box_border_grey"><img data-vc-zoom="https://marco.puruno.com/11/wp-content/uploads/sites/40/2017/01/6.jpg" width="380" height="600" src="wp-content/uploads/sites/40/2017/01/6.jpg" class="vc_single_image-img attachment-full" alt="" srcset="https://marco.puruno.com/11/wp-content/uploads/sites/40/2017/01/6.jpg 380w, https://marco.puruno.com/11/wp-content/uploads/sites/40/2017/01/6-190x300.jpg 190w" sizes="(max-width: 380px) 100vw, 380px" /></div>
		</figure>
	</div>
</div></div></div></div></div></div></div></div><div class="vc_row-full-width vc_clearfix"></div> </div><div data-vc-full-width="true" data-vc-full-width-init="false" data-vc-stretch-content="true" class="row-wrapper full-row vc_custom_1485175473981"><div class=""><div class="large-3 columns"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="mosaic-item id_160584271c6fb81503664147" data-sm-height="200" data-lg-height="530">
				<div class="mosaic-link">
					<div class="mosaic-img" style="background-image: url(../assets/img/5-2.jpg)"></div>
					<div class="mosaic-info" style="color: #ffffff">
						<div class="mosaic-text"><p>Hindu Fernandez, meet our magician.</p>
</div>
						<div class="mosaic-link">Head Chef</div>
					</div>
					<div class="mosaic-item-overlay"></div>
				</div>
			</div><div class="custom-styles" data-styles=".id_160584271c6fb81503664147 .mosaic-item-overlay { background: -moz-linear-gradient(top, rgba(0,0,0,0.01) 0%, #111111 100%); background: -webkit-linear-gradient(top,  rgba(0,0,0,0.01) 0%,#111111 100%); background: linear-gradient(to bottom,  rgba(0,0,0,0.01) 0%,#111111 100%); filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#b3000000', endColorstr='#b3000000',GradientType=0 ); }.id_160584271c6fb81503664147 .mosaic-info .mosaic-link:after { background: #ffffff; }"></div></div></div></div><div class="large-3 columns"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="mosaic-item id_160584271c72341504754737" data-sm-height="200" data-lg-height="300">
				<div class="mosaic-link">
					<div class="mosaic-img" style="background-image: url(../assets/img/7-1-1024x683.jpg)"></div>
					<div class="mosaic-info" style="color: #ffffff">

						<div class="mosaic-link">Private dining</div>
					</div>
					<div class="mosaic-item-overlay"></div>
				</div>
			</div><div class="custom-styles" data-styles=".id_160584271c72341504754737 .mosaic-item-overlay { background: -moz-linear-gradient(top, rgba(0,0,0,0.01) 0%, #111111 100%); background: -webkit-linear-gradient(top,  rgba(0,0,0,0.01) 0%,#111111 100%); background: linear-gradient(to bottom,  rgba(0,0,0,0.01) 0%,#111111 100%); filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#b3000000', endColorstr='#b3000000',GradientType=0 ); }.id_160584271c72341504754737 .mosaic-info .mosaic-link:after { background: #ffffff; }"></div><div class="mosaic-item id_160584271c73c12069502514" data-sm-height="200" data-lg-height="200">
				<div class="mosaic-link">
					<div class="mosaic-img" style="background-image: url(../assets/img/f3-1024x682.jpg)"></div>
					<div class="mosaic-info" style="color: #ffffff">

						<div class="mosaic-link">Cooking classes</div>
					</div>
					<div class="mosaic-item-overlay"></div>
				</div>
			</div><div class="custom-styles" data-styles=".id_160584271c73c12069502514 .mosaic-item-overlay { background: -moz-linear-gradient(top, rgba(0,0,0,0.01) 0%, #111111 100%); background: -webkit-linear-gradient(top,  rgba(0,0,0,0.01) 0%,#111111 100%); background: linear-gradient(to bottom,  rgba(0,0,0,0.01) 0%,#111111 100%); filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#b3000000', endColorstr='#b3000000',GradientType=0 ); }.id_160584271c73c12069502514 .mosaic-info .mosaic-link:after { background: #ffffff; }"></div></div></div></div><div class="large-3 columns"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="mosaic-item id_160584271c7642819385894" data-sm-height="200" data-lg-height="200">
				<div class="mosaic-link">
					<div class="mosaic-img" style="background-image: url(../assets/img/2-5.jpg)"></div>
					<div class="mosaic-info" style="color: #ffffff">

						<div class="mosaic-link">We blog</div>
					</div>
					<div class="mosaic-item-overlay"></div>
				</div>
			</div><div class="custom-styles" data-styles=".id_160584271c7642819385894 .mosaic-item-overlay { background: -moz-linear-gradient(top, rgba(0,0,0,0.01) 0%, #111111 100%); background: -webkit-linear-gradient(top,  rgba(0,0,0,0.01) 0%,#111111 100%); background: linear-gradient(to bottom,  rgba(0,0,0,0.01) 0%,#111111 100%); filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#b3000000', endColorstr='#b3000000',GradientType=0 ); }.id_160584271c7642819385894 .mosaic-info .mosaic-link:after { background: #ffffff; }"></div><div class="mosaic-item id_160584271c77bc1457454317" data-sm-height="200" data-lg-height="300">
				<div class="mosaic-link">
					<div class="mosaic-img" style="background-image: url(../assets/img/giftcard-1.jpg)"></div>
					<div class="mosaic-info" style="color: #ffffff">

						<div class="mosaic-link">Gift card</div>
					</div>
					<div class="mosaic-item-overlay"></div>
				</div>
			</div><div class="custom-styles" data-styles=".id_160584271c77bc1457454317 .mosaic-item-overlay { background: -moz-linear-gradient(top, rgba(0,0,0,0.01) 0%, #111111 100%); background: -webkit-linear-gradient(top,  rgba(0,0,0,0.01) 0%,#111111 100%); background: linear-gradient(to bottom,  rgba(0,0,0,0.01) 0%,#111111 100%); filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#b3000000', endColorstr='#b3000000',GradientType=0 ); }.id_160584271c77bc1457454317 .mosaic-info .mosaic-link:after { background: #ffffff; }"></div></div></div></div><div class="large-3 columns"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="mosaic-item id_160584271c7a001671646564" data-sm-height="200" data-lg-height="530">
				<div class="mosaic-link">
					<div class="mosaic-img" style="background-image: url(../assets/img/Untitled-8.jpg)"></div>
					<div class="mosaic-info" style="color: #ffffff">

						<div class="mosaic-link">Get in touch</div>
					</div>
					<div class="mosaic-item-overlay"></div>
				</div>
			</div><div class="custom-styles" data-styles=".id_160584271c7a001671646564 .mosaic-item-overlay { background: -moz-linear-gradient(top, rgba(0,0,0,0.01) 0%, #111111 100%); background: -webkit-linear-gradient(top,  rgba(0,0,0,0.01) 0%,#111111 100%); background: linear-gradient(to bottom,  rgba(0,0,0,0.01) 0%,#111111 100%); filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#b3000000', endColorstr='#b3000000',GradientType=0 ); }.id_160584271c7a001671646564 .mosaic-info .mosaic-link:after { background: #ffffff; }"></div></div></div></div></div><div class="vc_row-full-width vc_clearfix"></div> </div><div class="vc_row-full-width vc_clearfix"></div><div  class="row-wrapper  vc_custom_1485175494804"><div class="vc_row-o-equal-height vc_row-o-content-middle vc_row-flex"><div class="large-6 columns"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="row row_inner"><div class="large-6 small-6 columns"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_single_image wpb_content_element vc_align_left">

		<figure class="wpb_wrapper vc_figure">
			<div class="vc_single_image-wrapper img-wrapper   vc_box_border_grey"><img data-vc-zoom="https://marco.puruno.com/11/wp-content/uploads/sites/40/2017/01/4-1.jpg" width="380" height="300" src="wp-content/uploads/sites/40/2017/01/4-1.jpg" class="vc_single_image-img attachment-full" alt="" srcset="https://marco.puruno.com/11/wp-content/uploads/sites/40/2017/01/4-1.jpg 380w, https://marco.puruno.com/11/wp-content/uploads/sites/40/2017/01/4-1-300x237.jpg 300w" sizes="(max-width: 380px) 100vw, 380px" /></div>
		</figure>
	</div>

	<div class="wpb_single_image wpb_content_element vc_align_left">

		<figure class="wpb_wrapper vc_figure">
			<div class="vc_single_image-wrapper img-wrapper   vc_box_border_grey"><img data-vc-zoom="https://marco.puruno.com/11/wp-content/uploads/sites/40/2017/01/2-3.jpg" width="380" height="300" src="wp-content/uploads/sites/40/2017/01/2-3.jpg" class="vc_single_image-img attachment-full" alt="" srcset="https://marco.puruno.com/11/wp-content/uploads/sites/40/2017/01/2-3.jpg 380w, https://marco.puruno.com/11/wp-content/uploads/sites/40/2017/01/2-3-300x237.jpg 300w" sizes="(max-width: 380px) 100vw, 380px" /></div>
		</figure>
	</div>
</div></div></div><div class="large-6 small-6 columns"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_single_image wpb_content_element vc_align_left">

		<figure class="wpb_wrapper vc_figure">
			<div class="vc_single_image-wrapper img-wrapper   vc_box_border_grey"><img data-vc-zoom="https://marco.puruno.com/11/wp-content/uploads/sites/40/2017/01/3-2.jpg" width="380" height="300" src="wp-content/uploads/sites/40/2017/01/3-2.jpg" class="vc_single_image-img attachment-full" alt="" srcset="https://marco.puruno.com/11/wp-content/uploads/sites/40/2017/01/3-2.jpg 380w, https://marco.puruno.com/11/wp-content/uploads/sites/40/2017/01/3-2-300x237.jpg 300w" sizes="(max-width: 380px) 100vw, 380px" /></div>
		</figure>
	</div>

	<div class="wpb_single_image wpb_content_element vc_align_left">

		<figure class="wpb_wrapper vc_figure">
			<div class="vc_single_image-wrapper img-wrapper   vc_box_border_grey"><img data-vc-zoom="https://marco.puruno.com/11/wp-content/uploads/sites/40/2017/01/5-1.jpg" width="380" height="300" src="wp-content/uploads/sites/40/2017/01/5-1.jpg" class="vc_single_image-img attachment-full" alt="" srcset="https://marco.puruno.com/11/wp-content/uploads/sites/40/2017/01/5-1.jpg 380w, https://marco.puruno.com/11/wp-content/uploads/sites/40/2017/01/5-1-300x237.jpg 300w" sizes="(max-width: 380px) 100vw, 380px" /></div>
		</figure>
	</div>
</div></div></div></div></div></div></div><div class="large-6 columns"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="text-center page-header id_160584271c90212097640918 animate-text alt-h"><div style="color: #333333"></p>
<h3>Mouth-watering menu</h3>
<p></div><div class="post-meta">
					<ul>
						<li>Share on:</li>
						<li><a href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fmarco.puruno.com%2F11%2F" class="no-rd social-share link-hover" data-djax-exclude="true">Facebook</a></li>
		<li><a href="https://www.twitter.com/share?text=home-alt" class="no-rd social-share link-hover" data-djax-exclude="true">Twitter</a></li>


		<li><a href="https://pinterest.com/pin/create/bookmarklet/?media=&amp;url=https%3A%2F%2Fmarco.puruno.com%2F11%2F&amp;is_video=0&amp;description=" class="no-rd social-share link-hover" data-djax-exclude="true">Pinterest</a></li>
					</ul>
				</div></div><div class="custom-styles" data-styles=".id_160584271c90212097640918 .post-meta li a, .id_160584271c90212097640918 .post-meta { color: #333333 } .id_160584271c90212097640918 .link-hover:after {background:#333333}"></div>	<div class="vc_empty_space" >
		<span class="vc_empty_space_inner"></span>
		<div class=""  style="height: 32px"></div>
			</div>


	<div class="wpb_text_column wpb_content_element  vc_custom_1485160209071" >
		<div class="wpb_wrapper">
			<p style="text-align: center;">With glazed frontage on two sides of the building, overlooking the market and a bustling Barbican view.</p>

		</div>
	</div>
<div class="text-center animate-text"><a href="#"  class="btn btn-sm btn-border-animate btn-dark   ">
				<span class="btn-text ">View our menu<span class="top button-border"></span>
				<span class="left left-bottom button-border"></span>
				<span class="left left-top button-border"></span>
				<span class="bottom bottom-right button-border"></span>
				<span class="bottom bottom-left button-border"></span>
				<span class="right button-border"></span></span>
			</a></div>	<div class="vc_empty_space" >
		<span class="vc_empty_space_inner"></span>
		<div class="show-for-large"  style="height: 0px"></div>
		<div class="hide-for-large"  style="height: 62px"></div>	</div>

</div></div></div></div><div class="vc_row-full-width vc_clearfix"></div> </div><div data-vc-full-width="true" data-vc-full-width-init="false" class="row-wrapper full-row "><div data-marco-parallax="0.5" style="background-image: url(../assets/img/3.jpg)" class="marco-parallax"><div class="row-image-overlay" style="background-color: rgba(0,0,0,0.58)"></div></div><div class=""><div class="large-12 columns"><div class="vc_column-inner "><div class="wpb_wrapper">	<div class="vc_empty_space" >
		<span class="vc_empty_space_inner"></span>
		<div class=""  style="height: 200px"></div>
			</div>

<div class="text-center page-header id_160584271c97f9640114228 animate-text alt-h"><div style="color: #ffffff"></p>
<h2>Locally sourced, fresh ingredients.</h2>
<p></div><div class="post-meta">
					<ul>
						<li>Share on:</li>
						<li><a href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fmarco.puruno.com%2F11%2F" class="no-rd social-share link-hover" data-djax-exclude="true">Facebook</a></li>
		<li><a href="https://www.twitter.com/share?text=home-alt" class="no-rd social-share link-hover" data-djax-exclude="true">Twitter</a></li>


		<li><a href="https://pinterest.com/pin/create/bookmarklet/?media=&amp;url=https%3A%2F%2Fmarco.puruno.com%2F11%2F&amp;is_video=0&amp;description=" class="no-rd social-share link-hover" data-djax-exclude="true">Pinterest</a></li>
					</ul>
				</div></div><div class="custom-styles" data-styles=".id_160584271c97f9640114228 .post-meta li a, .id_160584271c97f9640114228 .post-meta { color: #ffffff } .id_160584271c97f9640114228 .link-hover:after {background:#ffffff}"></div>	<div class="vc_empty_space" >
		<span class="vc_empty_space_inner"></span>
		<div class=""  style="height: 200px"></div>
			</div>

</div></div></div></div><div class="vc_row-full-width vc_clearfix"></div> </div><div class="vc_row-full-width vc_clearfix"></div><div  class="row-wrapper  vc_custom_1485175502789"><div class="vc_row-o-equal-height vc_row-o-content-middle vc_row-flex"><div class="large-6 columns"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="text-center page-header id_160584271c9c01839537368 animate-text alt-h"><div style="color: #333333"></p>
<h3>Amazing team</h3>
<p></div><div class="post-meta">
					<ul>
						<li>Share on:</li>
						<li><a href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fmarco.puruno.com%2F11%2F" class="no-rd social-share link-hover" data-djax-exclude="true">Facebook</a></li>
		<li><a href="https://www.twitter.com/share?text=home-alt" class="no-rd social-share link-hover" data-djax-exclude="true">Twitter</a></li>


		<li><a href="https://pinterest.com/pin/create/bookmarklet/?media=&amp;url=https%3A%2F%2Fmarco.puruno.com%2F11%2F&amp;is_video=0&amp;description=" class="no-rd social-share link-hover" data-djax-exclude="true">Pinterest</a></li>
					</ul>
				</div></div><div class="custom-styles" data-styles=".id_160584271c9c01839537368 .post-meta li a, .id_160584271c9c01839537368 .post-meta { color: #333333 } .id_160584271c9c01839537368 .link-hover:after {background:#333333}"></div>	<div class="vc_empty_space" >
		<span class="vc_empty_space_inner"></span>
		<div class=""  style="height: 32px"></div>
			</div>


	<div class="wpb_text_column wpb_content_element  vc_custom_1484908829635" >
		<div class="wpb_wrapper">
			<p style="text-align: center;">Marco is a restaurant, bar and coffee roastery located on a busy corner site in Plymouth Hoe. With glazed frontage on two sides of the building, overlooking the market and a bustling Barbican view.</p>

		</div>
	</div>
<div class="text-center animate-text"><a href="#"  class="btn btn-sm btn-border-animate btn-dark   ">
				<span class="btn-text ">Meet all of them<span class="top button-border"></span>
				<span class="left left-bottom button-border"></span>
				<span class="left left-top button-border"></span>
				<span class="bottom bottom-right button-border"></span>
				<span class="bottom bottom-left button-border"></span>
				<span class="right button-border"></span></span>
			</a></div>	<div class="vc_empty_space" >
		<span class="vc_empty_space_inner"></span>
		<div class="show-for-large"  style="height: 0px"></div>
		<div class="hide-for-large"  style="height: 62px"></div>	</div>

</div></div></div><div class="large-6 columns"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="row row_inner"><div class="large-6 small-6 columns"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_single_image wpb_content_element vc_align_left">

		<figure class="wpb_wrapper vc_figure">
			<div class="vc_single_image-wrapper img-wrapper   vc_box_border_grey"><img data-vc-zoom="https://marco.puruno.com/11/wp-content/uploads/sites/40/2017/01/contact6.jpg" width="564" height="840" src="wp-content/uploads/sites/40/2017/01/contact6.jpg" class="vc_single_image-img attachment-full" alt="" srcset="https://marco.puruno.com/11/wp-content/uploads/sites/40/2017/01/contact6.jpg 564w, https://marco.puruno.com/11/wp-content/uploads/sites/40/2017/01/contact6-201x300.jpg 201w" sizes="(max-width: 564px) 100vw, 564px" /></div>
		</figure>
	</div>
</div></div></div><div class="large-6 small-6 columns"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_single_image wpb_content_element vc_align_left">

		<figure class="wpb_wrapper vc_figure">
			<div class="vc_single_image-wrapper img-wrapper   vc_box_border_grey"><img data-vc-zoom="https://marco.puruno.com/11/wp-content/uploads/sites/40/2017/01/reservation-683x1024.jpg" width="683" height="1024" src="wp-content/uploads/sites/40/2017/01/reservation.jpg" class="vc_single_image-img attachment-full" alt="" srcset="https://marco.puruno.com/11/wp-content/uploads/sites/40/2017/01/reservation.jpg 683w, https://marco.puruno.com/11/wp-content/uploads/sites/40/2017/01/reservation-200x300.jpg 200w" sizes="(max-width: 683px) 100vw, 683px" /></div>
		</figure>
	</div>
</div></div></div></div></div></div></div></div><div class="vc_row-full-width vc_clearfix"></div> </div><div  class="row-wrapper  "><div class=""><div class="large-12 columns"><div class="vc_column-inner "><div class="wpb_wrapper">	<div class="vc_empty_space" >
		<span class="vc_empty_space_inner"></span>
		<div class="show-for-large"  style="height: 100px"></div>
		<div class="hide-for-large"  style="height: 62px"></div>	</div>

<div class="text-center page-header id_160584271cad771711189783 animate-text alt-h"><div style="color: #333333"></p>
<h2>Ready to book your table?</h2>
<p></div><div class="post-meta">
					<ul>
						<li>Share on:</li>
						<li><a href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fmarco.puruno.com%2F11%2F" class="no-rd social-share link-hover" data-djax-exclude="true">Facebook</a></li>
		<li><a href="https://www.twitter.com/share?text=home-alt" class="no-rd social-share link-hover" data-djax-exclude="true">Twitter</a></li>


		<li><a href="https://pinterest.com/pin/create/bookmarklet/?media=&amp;url=https%3A%2F%2Fmarco.puruno.com%2F11%2F&amp;is_video=0&amp;description=" class="no-rd social-share link-hover" data-djax-exclude="true">Pinterest</a></li>
					</ul>
				</div></div><div class="custom-styles" data-styles=".id_160584271cad771711189783 .post-meta li a, .id_160584271cad771711189783 .post-meta { color: #333333 } .id_160584271cad771711189783 .link-hover:after {background:#333333}"></div>	<div class="vc_empty_space" >
		<span class="vc_empty_space_inner"></span>
		<div class=""  style="height: 50px"></div>
			</div>

<div class="row row_inner"><div class="large-6 columns"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element  vc_custom_1484914193068" >
		<div class="wpb_wrapper">
			<p><strong>Booking a table</strong></p>
<p>Booking is easy. To make reservation, please call us at +1 555 890 901 between 9am-8pm, Monday to Friday or use the form bellow.</p>
<p>There are always 10% of walk-ins ready places.We do not book sofa &amp; bar area.</p>

		</div>
	</div>
	<div class="vc_empty_space" >
		<span class="vc_empty_space_inner"></span>
		<div class=""  style="height: 50px"></div>
			</div>

</div></div></div><div class="large-6 columns"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element  vc_custom_1484914177000" >
		<div class="wpb_wrapper">
			<p><strong>Private dining &amp; events</strong></p>
<p>There are four private spaces available for lunch, dinner or indeed at any other time like <a href="#">receptions</a>, <a href="#">presentations</a> or <a href="#">brainstorms</a>. In addition the restaurant is available for breakfast &amp; private hire as are all the other spaces.</p>
<p><a href="#"><em>Learn more</em></a></p>

		</div>
	</div>
	<div class="vc_empty_space" >
		<span class="vc_empty_space_inner"></span>
		<div class=""  style="height: 50px"></div>
			</div>

</div></div></div></div></div></div></div></div><div class="vc_row-full-width vc_clearfix"></div> </div><div  class="row-wrapper  "><div class=""><div class="large-12 columns"><div class="vc_column-inner "><div class="wpb_wrapper">	<div class="vc_empty_space" >
		<span class="vc_empty_space_inner"></span>
		<div class=""  style="height: 50px"></div>
			</div>

<div class="form-container form-with-image img_left id_160584271cb7a51600789191"><div class="form-image">
					<div class="form-image-wrapper show-for-large">
						<span class="img-wrapper">
							<img width="683" height="1024" src="wp-content/uploads/sites/40/2017/01/reservation1-683x1024.jpg" class="attachment-large size-large" alt="" srcset="https://marco.puruno.com/11/wp-content/uploads/sites/40/2017/01/reservation1.jpg 683w, https://marco.puruno.com/11/wp-content/uploads/sites/40/2017/01/reservation1-200x300.jpg 200w" sizes="(max-width: 683px) 100vw, 683px" />
						</span>
					</div>
				</div><div class="forms-style marco-form open-table-form animate-text">
					<div class="form-wrapper">
						<form method="get" action="https://www.opentable.com/restaurant-search.aspx" target="_blank">
							<fieldset class="open-table-details">
								<div class="date mf-input ot-input">
									<label for="date-otreservations" style="color: #111111">Date</label>
									<input id="date-otreservations" name="startDate" class="otw-reservation-date" type="text" style="color: #111111" autocomplete="off">
								</div>
								<div class="time mf-input ot-input">
									<label for="time-otreservations" style="color: #111111">Time</label>
									<input class="otw-reservation-time" type="text" id="time-otreservations" name="ResTime" style="color: #111111">
								</div>
								<div class="party mf-input ot-input">
									<label for="party-otreservations" style="color: #111111">Party size</label>
									<input class="otw-party-size-select" type="number" min="1" id="party-otreservations" name="partySize" style="color: #111111">
								</div>
							</fieldset>
							<div class="text-center"><button type="submit" class="btn btn-lg btn-border-animate btn-dark  ">
				<span class="btn-text ">Find a table<span class="top button-border"></span>
				<span class="left left-bottom button-border"></span>
				<span class="left left-top button-border"></span>
				<span class="bottom bottom-right button-border"></span>
				<span class="bottom bottom-left button-border"></span>
				<span class="right button-border"></span></span>
			</button></div>
							<input type="hidden" name="RestaurantID" class="RestaurantID" value="47125">
						 	<input type="hidden" name="rid" class="rid" value="47125">
						 	<input type="hidden" name="txtDateFormat" class="txtDateFormat" value="DD/MMMM/YYYY"> <input type="hidden" name="RestaurantReferralID" class="RestaurantReferralID" value="47125">
						</form>
					</div>
				</div></div><div class="custom-styles" data-styles=".id_160584271cb7a51600789191 .forms-style .ot-input .border-label:after, .id_160584271cb7a51600789191 .ot-input:after { background-color: #111111 !important;  } .id_160584271cb7a51600789191 .forms-style .ot-input .border-label:after { background-color: #111111;  } .id_160584271cb7a51600789191 .open-table-form fieldset:after { background-color: #dddddd; }"></div>	<div class="vc_empty_space" >
		<span class="vc_empty_space_inner"></span>
		<div class=""  style="height: 100px"></div>
			</div>

</div></div></div></div><div class="vc_row-full-width vc_clearfix"></div> </div>

			</div>
	</div>
</div>
</div>
@include('common/footer')
@include('common/script')
</body>

<!-- Mirrored from marco.puruno.com/11/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 22 Mar 2021 07:09:37 GMT -->
</html>
<!--
Performance optimized by W3 Total Cache. Learn more: https://www.w3-edge.com/products/

Page Caching using disk: enhanced (SSL caching disabled)
Database Caching 144/145 queries in 0.012 seconds using disk

Served from: marco.puruno.com @ 2021-03-22 07:08:33 by W3 Total Cache
-->
