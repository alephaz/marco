<!DOCTYPE html>
<html lang="en-US" class="no-js no-svg">

<!-- Mirrored from marco.puruno.com/11/about/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 22 Mar 2021 07:15:16 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<?php echo $__env->make('common/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body data-rsssl=1 class="page-template-default page page-id-14 nav-classes nav-left nav-top nav-solid nav-dark-text wpb-js-composer js-comp-ver-5.6 vc_responsive"  data-height-fixed-nav="80" >
	<div class="navigation-top">
		<div class="wrap">

<?php echo $__env->make('common/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		</div>
	</div>
	<?php echo $__env->make('common/stickynb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div class="page-wrapper">

	<div class="classic">
	<div class="row">
		<div class="small-12 columns small-centered blog-content">
									<div  class="row-wrapper  vc_custom_1485183756903"><div class="mosaic"><div class="large-3 columns"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="mosaic-item id_1605842a5b35a22007133191" data-sm-height="300" data-lg-height="500">
				<a class="mosaic-link" href="../../1/team4/index.html"  >
					<div class="mosaic-img" style="background-image: url(../assets/img/reservation-683x1024.jpg)"></div>
					<div class="mosaic-info" style="color: #ffffff">
						<div class="mosaic-text"><p>I am Theres, your host at Marco&#8217;s.</p>
</div>
						<div class="mosaic-link">Team</div>
					</div>
					<div class="mosaic-item-overlay"></div>
				</a>
			</div><div class="custom-styles" data-styles=".id_1605842a5b35a22007133191 .mosaic-item-overlay { background: -moz-linear-gradient(top, rgba(0,0,0,0.01) 0%, #111111 100%); background: -webkit-linear-gradient(top,  rgba(0,0,0,0.01) 0%,#111111 100%); background: linear-gradient(to bottom,  rgba(0,0,0,0.01) 0%,#111111 100%); filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#b3000000', endColorstr='#b3000000',GradientType=0 ); }.id_1605842a5b35a22007133191 .mosaic-info .mosaic-link:after { background: #ffffff; }"></div><div class="mosaic-item id_1605842a5b37de1486952282" data-sm-height="300" data-lg-height="300">
				<a class="mosaic-link" href="../../1/contact/index.html"  >
					<div class="mosaic-img" style="background-image: url(../assets/img/dark-wood-background.jpg)"></div>
					<div class="mosaic-info" style="color: #ffffff">
						<div class="mosaic-text"><p>Monday 10 &#8211; 21<br />
Tuesday 10 &#8211; 21<br />
Wednesday 10 &#8211; 21<br />
Thursday 10 &#8211; 21<br />
Saturaday 10 &#8211; 21</p>
</div>
						<div class="mosaic-link">Openning hours</div>
					</div>
					<div class="mosaic-item-overlay"></div>
				</a>
			</div><div class="custom-styles" data-styles=".id_1605842a5b37de1486952282 .mosaic-item-overlay { background: -moz-linear-gradient(top, rgba(0,0,0,0.01) 0%, #111111 100%); background: -webkit-linear-gradient(top,  rgba(0,0,0,0.01) 0%,#111111 100%); background: linear-gradient(to bottom,  rgba(0,0,0,0.01) 0%,#111111 100%); filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#b3000000', endColorstr='#b3000000',GradientType=0 ); }.id_1605842a5b37de1486952282 .mosaic-info .mosaic-link:after { background: #ffffff; }"></div></div></div></div><div class="large-3 columns"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="mosaic-item id_1605842a5b3de61384121655" data-sm-height="300" data-lg-height="300">
				<a class="mosaic-link" href="../../1/menu/index.html"  >
					<div class="mosaic-img" style="background-image: url(../assets/img/Untitled-8-1.jpg)"></div>
					<div class="mosaic-info" style="color: #ffffff">

						<div class="mosaic-link">MENU</div>
					</div>
					<div class="mosaic-item-overlay"></div>
				</a>
			</div><div class="custom-styles" data-styles=".id_1605842a5b3de61384121655 .mosaic-item-overlay { background: -moz-linear-gradient(top, rgba(0,0,0,0.01) 0%, #111111 100%); background: -webkit-linear-gradient(top,  rgba(0,0,0,0.01) 0%,#111111 100%); background: linear-gradient(to bottom,  rgba(0,0,0,0.01) 0%,#111111 100%); filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#b3000000', endColorstr='#b3000000',GradientType=0 ); }.id_1605842a5b3de61384121655 .mosaic-info .mosaic-link:after { background: #ffffff; }"></div><div class="mosaic-item id_1605842a5b422d915840114" data-sm-height="300" data-lg-height="500">
				<a class="mosaic-link" href="../../1/blog/index.html"  >
					<div class="mosaic-img" style="background-image: url(../assets/img/s7-1024x1024.jpg)"></div>
					<div class="mosaic-info" style="color: #ffffff">
						<div class="mosaic-text"><p>Toast anchois facile</p>
</div>
						<div class="mosaic-link">Specials</div>
					</div>
					<div class="mosaic-item-overlay"></div>
				</a>
			</div><div class="custom-styles" data-styles=".id_1605842a5b422d915840114 .mosaic-item-overlay { background: -moz-linear-gradient(top, rgba(0,0,0,0.01) 0%, #111111 100%); background: -webkit-linear-gradient(top,  rgba(0,0,0,0.01) 0%,#111111 100%); background: linear-gradient(to bottom,  rgba(0,0,0,0.01) 0%,#111111 100%); filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#b3000000', endColorstr='#b3000000',GradientType=0 ); }.id_1605842a5b422d915840114 .mosaic-info .mosaic-link:after { background: #ffffff; }"></div></div></div></div><div class="large-3 columns"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="mosaic-item id_1605842a5b488382857798" data-sm-height="300" data-lg-height="400">
				<a class="mosaic-link" href="../../1/our-food/index.html"  >
					<div class="mosaic-img" style="background-image: url(../assets/img/6-1.jpg)"></div>
					<div class="mosaic-info" style="color: #ffffff">

						<div class="mosaic-link">Food</div>
					</div>
					<div class="mosaic-item-overlay"></div>
				</a>
			</div><div class="custom-styles" data-styles=".id_1605842a5b488382857798 .mosaic-item-overlay { background: -moz-linear-gradient(top, rgba(0,0,0,0.01) 0%, #111111 100%); background: -webkit-linear-gradient(top,  rgba(0,0,0,0.01) 0%,#111111 100%); background: linear-gradient(to bottom,  rgba(0,0,0,0.01) 0%,#111111 100%); filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#b3000000', endColorstr='#b3000000',GradientType=0 ); }.id_1605842a5b488382857798 .mosaic-info .mosaic-link:after { background: #ffffff; }"></div><div class="mosaic-item id_1605842a5b4da42039323521" data-sm-height="300" data-lg-height="400">
				<a class="mosaic-link" href="../../1/reservation/index.html"  >
					<div class="mosaic-img" style="background-image: url(../assets/img/gallery-1024x767.jpg)"></div>
					<div class="mosaic-info" style="color: #ffffff">
						<div class="mosaic-text"><p>When would you like to visit?</p>
</div>
						<div class="mosaic-link">Book your table</div>
					</div>
					<div class="mosaic-item-overlay"></div>
				</a>
			</div><div class="custom-styles" data-styles=".id_1605842a5b4da42039323521 .mosaic-item-overlay { background: -moz-linear-gradient(top, rgba(0,0,0,0.01) 0%, #111111 100%); background: -webkit-linear-gradient(top,  rgba(0,0,0,0.01) 0%,#111111 100%); background: linear-gradient(to bottom,  rgba(0,0,0,0.01) 0%,#111111 100%); filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#b3000000', endColorstr='#b3000000',GradientType=0 ); }.id_1605842a5b4da42039323521 .mosaic-info .mosaic-link:after { background: #ffffff; }"></div></div></div></div><div class="large-3 columns"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="mosaic-item id_1605842a5b5345864736772" data-sm-height="300" data-lg-height="500">
				<a class="mosaic-link" href="../../1/private-dining/index.html"  >
					<div class="mosaic-img" style="background-image: url(../assets/img/7-1-1024x683.jpg)"></div>
					<div class="mosaic-info" style="color: #ffffff">
						<div class="mosaic-text"><p>Eating, drinking and relaxing. We believe these need to be united.</p>
</div>
						<div class="mosaic-link">Private dining</div>
					</div>
					<div class="mosaic-item-overlay"></div>
				</a>
			</div><div class="custom-styles" data-styles=".id_1605842a5b5345864736772 .mosaic-item-overlay { background: -moz-linear-gradient(top, rgba(0,0,0,0.01) 0%, #111111 100%); background: -webkit-linear-gradient(top,  rgba(0,0,0,0.01) 0%,#111111 100%); background: linear-gradient(to bottom,  rgba(0,0,0,0.01) 0%,#111111 100%); filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#b3000000', endColorstr='#b3000000',GradientType=0 ); }.id_1605842a5b5345864736772 .mosaic-info .mosaic-link:after { background: #ffffff; }"></div><div class="mosaic-item id_1605842a5b552e2075055870" data-sm-height="300" data-lg-height="300">
				<a class="mosaic-link" href="../../1/gallery/index.html"  >
					<div class="mosaic-img" style="background-image: url(../assets/img/2-6-1024x640.jpg)"></div>
					<div class="mosaic-info" style="color: #ffffff">
						<div class="mosaic-text"><p>First class experience</p>
</div>
						<div class="mosaic-link">Dine in style</div>
					</div>
					<div class="mosaic-item-overlay"></div>
				</a>
			</div><div class="custom-styles" data-styles=".id_1605842a5b552e2075055870 .mosaic-item-overlay { background: -moz-linear-gradient(top, rgba(0,0,0,0.01) 0%, #111111 100%); background: -webkit-linear-gradient(top,  rgba(0,0,0,0.01) 0%,#111111 100%); background: linear-gradient(to bottom,  rgba(0,0,0,0.01) 0%,#111111 100%); filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#b3000000', endColorstr='#b3000000',GradientType=0 ); }.id_1605842a5b552e2075055870 .mosaic-info .mosaic-link:after { background: #ffffff; }"></div></div></div></div></div><div class="vc_row-full-width vc_clearfix"></div> </div>
		</div>
			</div>
</div>

</div>
<?php echo $__env->make('common/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('common/script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

<!-- Mirrored from marco.puruno.com/11/about/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 22 Mar 2021 07:15:19 GMT -->
</html>
<!--
Performance optimized by W3 Total Cache. Learn more: https://www.w3-edge.com/products/

Page Caching using disk: enhanced (SSL caching disabled)
Database Caching 104/124 queries in 0.014 seconds using disk

Served from: marco.puruno.com @ 2021-03-22 07:09:25 by W3 Total Cache
-->
<?php /**PATH C:\Users\Yuwan Thilakasiri\Desktop\New folder (5)\Via Torino\viatorino\resources\views/about.blade.php ENDPATH**/ ?>