<!DOCTYPE html>
<html lang="en-US" class="no-js no-svg">

<!-- Mirrored from marco.puruno.com/11/menu/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 22 Mar 2021 07:15:19 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<?php echo $__env->make('common/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body data-rsssl=1 class="page-template-default page page-id-5 nav-classes nav-left nav-top nav-solid nav-dark-text wpb-js-composer js-comp-ver-5.6 vc_responsive"  data-height-fixed-nav="80" >
	<div class="navigation-top">
		<div class="wrap">


<?php echo $__env->make('common/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		</div>
	</div>
	<?php echo $__env->make('common/stickynb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div class="page-wrapper">

	<div class="classic">
	<div class="row">
		<div class="small-12 columns small-centered blog-content">
									<div  class="row-wrapper  vc_custom_1485186183447"><div class=""><div class="large-6 columns"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="text-left page-header id_1605842a5b3957830799441 animate-text "><div style="color: #333333"></p>
<h3>Our menu is based on local products and passionate cooking</h3>
<p></div><div class="post-meta">
					<ul>
						<li>Share on:</li>
						<li><a href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fmarco.puruno.com%2F11%2Fmenu%2F" class="no-rd social-share link-hover" data-djax-exclude="true">Facebook</a></li>
		<li><a href="https://www.twitter.com/share?text=Menu" class="no-rd social-share link-hover" data-djax-exclude="true">Twitter</a></li>


		<li><a href="https://pinterest.com/pin/create/bookmarklet/?media=&amp;url=https%3A%2F%2Fmarco.puruno.com%2F11%2Fmenu%2F&amp;is_video=0&amp;description=" class="no-rd social-share link-hover" data-djax-exclude="true">Pinterest</a></li>
					</ul>
				</div></div><div class="custom-styles" data-styles=".id_1605842a5b3957830799441 .post-meta li a, .id_1605842a5b3957830799441 .post-meta { color: #333333 } .id_1605842a5b3957830799441 .link-hover:after {background:#333333}"></div></div></div></div><div class="large-6 columns"><div class="vc_column-inner "><div class="wpb_wrapper"></div></div></div></div><div class="vc_row-full-width vc_clearfix"></div> </div><div  class="row-wrapper  "><div class=""><div class="large-12 columns"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="food-menu food-menu-img page-padding-top all-img-right cat-above-items id_1605842a5b3ebf1232643857" data-sp="1"><div class="row">
			<div class="food-menu-filters small-12 columns ">
				<ul class="food-menu-filters-list filters-right"><li class="active-filter"><a href="#" data-id="21" data-slug="menu">Day menu</a></li><li><a href="#" data-id="22" data-slug="brunch">Brunch</a></li><li><a href="#" data-id="17" data-slug="beverage">Beverage</a></li> </ul>
				</div>
			</div><div class="food-menu-container"><div class="grid-sizer"></div><div class="food-menu-category animate-text"><div class="food-menu-cat-img"><div class="food-menu-cat-header" data-id="14" data-slug="starters"><h4>Starters</h4><div class="food-menu-subtitle"><p>Maecenas faucibus mollis interdum. Sed posuere consectetur est at lobortis.</p>
</div></div><div class="food-menu-featured-img"><span class="img-wrapper"><img src="<?php echo e(asset('assets/img/menu2.jpg')); ?>" data-id="14" alt="food-item-img"/></span></div></div><div class="food-menu-items"><div class="food-menu-cat-header" data-id="14" data-slug="starters"><h4>Starters</h4><div class="food-menu-subtitle"><p>Maecenas faucibus mollis interdum. Sed posuere consectetur est at lobortis.</p>
</div></div><div class="food-menu-item "><div class="food-menu-item-header "><div class="food-menu-title">roasted prawns with coriander</div><div class="food-menu-price">$23</div></div><div class="food-menu-desc"><p>corn purée, corn, bell pepper ketchup, lamb’s lettuce</p>
</div></div><div class="food-menu-item "><div class="food-menu-item-header "><div class="food-menu-title">beetroot carpaccio,</div><div class="food-menu-price">$24</div></div><div class="food-menu-desc"><p>marinated salmon with dill, beetroot, hazelnuts, beetroot leaves</p>
</div></div><div class="food-menu-item "><div class="food-menu-item-header food-menu-featured"><div class="food-menu-title">foie gras terrine</div><div class="food-menu-price">$29 / dish of the day /</div></div><div class="food-menu-desc"><p>cranberry jelly, pumpkin purée and sponge, pickled mushrooms, figs</p>
</div></div><div class="food-menu-item "><div class="food-menu-item-header "><div class="food-menu-title">tom kha kai</div><div class="food-menu-price">$32</div></div><div class="food-menu-desc"><p>tiger prawns, chicken, wakame</p>
</div></div><div class="food-menu-item "><div class="food-menu-item-header "><div class="food-menu-title">consommé of beef ribs</div><div class="food-menu-price">$31</div></div><div class="food-menu-desc"><p>julienne vegetables, crunchy noodles, beef</p>
</div></div><div class="food-menu-item "><div class="food-menu-item-header "><div class="food-menu-title">cream of jerusalem artichoke soup</div><div class="food-menu-price">$23</div></div><div class="food-menu-desc"><p>foie gras panna cotta, chips of jerusalem artichoke, edible flowers</p>
</div></div><div class="food-menu-item "><div class="food-menu-item-header "><div class="food-menu-title">salad with blue cheese</div><div class="food-menu-price">$28 (vegan)</div></div><div class="food-menu-desc"><p>pears marinated in port wine and lemon, walnuts, rice chips, elderberry dressing</p>
</div></div><div class="food-menu-item "><div class="food-menu-item-header "><div class="food-menu-title">beef tartare</div><div class="food-menu-price">$31</div></div><div class="food-menu-desc"><p>tarragon mayonnaise, marinated shimeji mushrooms, black toast, herbs</p>
</div></div><div class="food-menu-item "><div class="food-menu-item-header "><div class="food-menu-title">variation of homemade bread</div><div class="food-menu-price">$14 per person</div></div><div class="food-menu-desc"><p>tapioca bread with greek cheese and curd, pumpkin bread, baguette with sesame seeds and herb butter</p>
</div></div></div></div><div class="food-menu-category animate-text"><div class="food-menu-cat-img"><div class="food-menu-cat-header" data-id="15" data-slug="mains"><h4>Mains</h4><div class="food-menu-subtitle"><p>Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Maecenas faucibus mollis interdum. Sed posuere consectetur est at lobortis.</p>
</div></div><div class="food-menu-featured-img"><span class="img-wrapper"><img src="<?php echo e(asset('assets/img/6-1.jpg')); ?>" data-id="15" alt="food-item-img"/></span></div></div><div class="food-menu-items"><div class="food-menu-cat-header" data-id="15" data-slug="mains"><h4>Mains</h4><div class="food-menu-subtitle"><p>Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Maecenas faucibus mollis interdum. Sed posuere consectetur est at lobortis.</p>
</div></div><div class="food-menu-item "><div class="food-menu-item-header "><div class="food-menu-title">veal mini escalopes</div><div class="food-menu-price">$36</div></div><div class="food-menu-desc"><p>potato salad, cornichons, mustard, marinated beetroot</p>
</div></div><div class="food-menu-item "><div class="food-menu-item-header food-menu-featured"><div class="food-menu-title">ravioli filled with baked pumpkin and goat cheese</div><div class="food-menu-price">$38</div></div><div class="food-menu-desc"><p>ricotta sauce, basil foam, roasted nuts</p>
</div></div><div class="food-menu-item "><div class="food-menu-item-header "><div class="food-menu-title">beef rib sous vide for 16 hours</div><div class="food-menu-price">$37</div></div><div class="food-menu-desc"><p>home fries fried in duck fat, coleslaw</p>
</div></div><div class="food-menu-item "><div class="food-menu-item-header "><div class="food-menu-title">pork belly</div><div class="food-menu-price">$37</div></div><div class="food-menu-desc"><p>homemade hash, white cabbage purée, potatoes with barley, marjoram sauce</p>
</div></div><div class="food-menu-item "><div class="food-menu-item-header "><div class="food-menu-title">tafelspitz</div><div class="food-menu-price">$38</div></div><div class="food-menu-desc"><p>celery, carrot, saffron potatoes, spring onion, dijon mustard, horseradish</p>
</div></div><div class="food-menu-item "><div class="food-menu-item-header "><div class="food-menu-title">pike-perch</div><div class="food-menu-price">$32</div></div><div class="food-menu-desc"><p>celery root purée, buttered carrots, sous vide leeks, herbs</p>
</div></div><div class="food-menu-item "><div class="food-menu-item-header "><div class="food-menu-title">teriyaki salmon</div><div class="food-menu-price">$39</div></div><div class="food-menu-desc"><p>zucchini, sugar snap peas, noodles, shiitake mushrooms, spring onion, lime</p>
</div></div><div class="food-menu-item "><div class="food-menu-item-header "><div class="food-menu-title">octopus</div><div class="food-menu-price">$46</div></div><div class="food-menu-desc"><p>wasabi purée, pak choi, soy sprouts, coconut-lime sauce</p>
</div></div><div class="food-menu-item "><div class="food-menu-item-header food-menu-featured"><div class="food-menu-title">fish of the day</div><div class="food-menu-price">$49</div></div><div class="food-menu-desc"><p>different fish every day of the week, ask stuff for assistance</p>
</div></div></div></div><div class="food-menu-category animate-text"><div class="food-menu-cat-img"><div class="food-menu-cat-header" data-id="16" data-slug="desserts"><h4>Desserts</h4><div class="food-menu-subtitle"><p>Morbi leo risus, porta ac consectetur ac, vestibulum at eros. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
</div></div><div class="food-menu-featured-img"><span class="img-wrapper"><img src="<?php echo e(asset('assets/img/cake.jpg')); ?>" data-id="16" alt="food-item-img"/></span></div></div><div class="food-menu-items"><div class="food-menu-cat-header" data-id="16" data-slug="desserts"><h4>Desserts</h4><div class="food-menu-subtitle"><p>Morbi leo risus, porta ac consectetur ac, vestibulum at eros. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
</div></div><div class="food-menu-item "><div class="food-menu-item-header "><div class="food-menu-title">apple strudel</div><div class="food-menu-price">$23</div></div><div class="food-menu-desc"><p>punch ice cream, cocoa sponge, roasted raisins and walnuts with rum</p>
</div></div><div class="food-menu-item "><div class="food-menu-item-header "><div class="food-menu-title">chocolate cheesecake</div><div class="food-menu-price">$23</div></div><div class="food-menu-desc"><p>banana cream, raspberries, banana sorbet, white and milk chocolate</p>
</div></div><div class="food-menu-item "><div class="food-menu-item-header "><div class="food-menu-title">curd cheese dumplings</div><div class="food-menu-price">$22</div></div><div class="food-menu-desc"><p>plum sauce with plum brandy, curd chips, caramelized plums, poppy seed ice cream</p>
</div></div><div class="food-menu-item "><div class="food-menu-item-header food-menu-featured-price"><div class="food-menu-title">selection of ice creams and sorbets</div><div class="food-menu-price">$2 per scoop</div></div><div class="food-menu-desc"><p>various flavours of freslhy made sweet treats</p>
</div></div><div class="food-menu-item "><div class="food-menu-item-header "><div class="food-menu-title">selection of european cheeses</div><div class="food-menu-price">$28</div></div><div class="food-menu-desc"><p>grapes, celery, seasonal chutney, homemade brioche</p>
</div></div><div class="food-menu-item "><div class="food-menu-item-header "><div class="food-menu-title">homemade pralines and macaroons served with coffee</div><div class="food-menu-price">$23</div></div><div class="food-menu-desc"></div></div></div></div></div><div class="food-menu-container-new"></div></div><div class="custom-styles" data-styles=".id_1605842a5b3ebf1232643857.food-menu .food-menu-cat-header h4, .id_1605842a5b3ebf1232643857.food-menu .food-menu-title, .id_1605842a5b3ebf1232643857.food-menu .food-menu-price, .id_1605842a5b3ebf1232643857 .food-menu-filters-list li a { color: #333333 } .id_1605842a5b3ebf1232643857 .food-menu-filters-list li:after, .id_1605842a5b3ebf1232643857 .food-menu-image-active .food-menu-icon { background: #333333; } .id_1605842a5b3ebf1232643857 .food-menu-icon { border-color: #333333} .id_1605842a5b3ebf1232643857 .food-menu-desc { color: #8a8a8a; } .id_1605842a5b3ebf1232643857 .food-menu-filters-list:after, .id_1605842a5b3ebf1232643857 .food-menu-item-header:after { background: #dddddd} .id_1605842a5b3ebf1232643857 .food-menu-featured.food-menu-item-header:after, .id_1605842a5b3ebf1232643857 .food-menu-featured-price .food-menu-price:after,  .id_1605842a5b3ebf1232643857 .food-menu-featured-title .food-menu-title:after { background: #f10a4a; }"></div></div></div></div></div><div class="vc_row-full-width vc_clearfix"></div> </div>
		</div>
			</div>
</div>

</div>
<?php echo $__env->make('common/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('common/script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

<!-- Mirrored from marco.puruno.com/11/menu/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 22 Mar 2021 07:15:20 GMT -->
</html>
<!--
Performance optimized by W3 Total Cache. Learn more: https://www.w3-edge.com/products/

Page Caching using disk: enhanced (SSL caching disabled)
Database Caching 106/130 queries in 0.023 seconds using disk

Served from: marco.puruno.com @ 2021-03-22 07:09:25 by W3 Total Cache
-->
<?php /**PATH C:\Users\Yuwan Thilakasiri\Desktop\New folder (5)\Via Torino\viatorino\resources\views/menu.blade.php ENDPATH**/ ?>